# KeyRx Portable Distribution

This is a portable distribution of KeyRx keyboard remapper.

## Installation

1. Extract this ZIP file to your preferred location (e.g., C:\Program Files\KeyRx)
2. Add the 'bin' directory to your PATH:
   - Right-click 'This PC' -> Properties -> Advanced system settings
   - Click 'Environment Variables'
   - Under 'System variables', find 'Path' and click 'Edit'
   - Click 'New' and add: C:\path\to\KeyRx\bin
   - Click 'OK' on all dialogs

## Usage

Open PowerShell or Command Prompt:

`powershell
# List available keyboards
keyrx_daemon list-devices

# Run daemon with configuration
keyrx_daemon run --config config\example_layout.krx

# View help
keyrx_daemon --help
`

## Configuration

Configuration files are stored in:
- %LOCALAPPDATA%\keyrx\profiles\
- %LOCALAPPDATA%\keyrx\devices.json

## Web UI

The daemon includes a web UI accessible at:
- http://localhost:9867

## Uninstallation

Simply delete this directory. Configuration files will remain in:
- %LOCALAPPDATA%\keyrx\

## Support

- GitHub: https://github.com/RyosukeMondo/keyrx
- Documentation: See README.md

